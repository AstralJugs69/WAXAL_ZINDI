# Production inference pipeline
